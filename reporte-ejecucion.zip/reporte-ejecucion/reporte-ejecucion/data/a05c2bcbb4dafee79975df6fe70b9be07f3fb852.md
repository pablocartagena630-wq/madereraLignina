# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: us04-06-catalogo.spec.js >> US-06 · Ver la venta de la semana (MLIG-6) >> CP-06.2 · "Comprar" de "Silla de caña" no apunta a "#"
- Location: tests/us04-06-catalogo.spec.js:135:5

# Error details

```
Error: el enlace Comprar debe ejecutar una compra

expect(received).not.toBe(expected) // Object.is equality

Expected: not "#"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - generic [ref=e3]:
      - generic [ref=e4]:
        - img "logo" [ref=e5]
        - link "Registrarse" [ref=e6] [cursor=pointer]:
          - /url: ../pages-01/registro.html
        - link "Ingresar" [ref=e7] [cursor=pointer]:
          - /url: ../pages-01/ingreso.html
        - link [ref=e8] [cursor=pointer]:
          - /url: ../pages-01/carro_de_compras.html
          - img "carrodecompras" [ref=e9]
      - navigation [ref=e11]:
        - list [ref=e12]:
          - listitem [ref=e13]:
            - link "Nosotros" [ref=e14] [cursor=pointer]:
              - /url: ../pages-01/seccion1.html
          - listitem [ref=e15]:
            - link "Categorías" [ref=e16] [cursor=pointer]:
              - /url: ../pages-01/seccion2.html
          - listitem [ref=e17]:
            - link "Venta de la semana" [ref=e18] [cursor=pointer]:
              - /url: ../pages-01/seccion3.html
          - listitem [ref=e19]:
            - link "Consejos" [ref=e20] [cursor=pointer]:
              - /url: ../pages-01/seccion4.html
          - listitem [ref=e21]:
            - link "Comentarios" [ref=e22] [cursor=pointer]:
              - /url: ../pages-01/seccion5.html
          - listitem [ref=e23]:
            - link "Volver al inicio" [ref=e24] [cursor=pointer]:
              - /url: ../index.html
  - main [ref=e25]:
    - generic [ref=e26]:
      - heading "Venta de la semana" [level=2] [ref=e28]
      - generic [ref=e29]:
        - generic [ref=e30]:
          - heading "Banco de madera" [level=3] [ref=e31]
          - paragraph [ref=e32]: Les presentamos el banco de madera. Posee herrajes metálicos resistentes y de pequeño tamaño. Con patas de un alto promedio y base amortiguadore es apta para todo piso y permite un apoyo cómodo y resistente. Esta compuesto por madera de Lapacho, lo cual resulta en un elemento de peso mediano y de gran duración frente a agentes climaticos extremos. Es resistente a golpes y abrasión por distintos objetos. Se encuentra revestido de una fina capa de barniz para potenciar sus colores naturales junto con una protección frente a la humedad.
        - img "seccion3" [ref=e34]
        - table [ref=e37]:
          - rowgroup [ref=e38]:
            - row [ref=e39]:
              - columnheader "Producto" [ref=e40]
              - columnheader "Especificaciones" [ref=e41]
              - columnheader "Costo" [ref=e42]
              - columnheader "Beneficios" [ref=e43]
              - columnheader "Recomendaciones" [ref=e44]
            - row [ref=e45]:
              - cell "Banco de madera" [ref=e46]
              - cell [ref=e47]:
                - list [ref=e48]:
                  - listitem [ref=e49]: Altura de 50cm
                  - listitem [ref=e50]: Largo de 150cm
                  - listitem [ref=e51]: Peso de 10,5kg
                  - listitem [ref=e52]: Uso interior
              - cell "$1550" [ref=e53]
              - cell [ref=e54]:
                - list [ref=e55]:
                  - listitem [ref=e56]: Impermeable
                  - listitem [ref=e57]: Liviano
                  - listitem [ref=e58]: Resistente
                  - listitem [ref=e59]: Permite su uso con otros muebles de la mismaángulo.
              - cell [ref=e60]:
                - list [ref=e61]:
                  - listitem [ref=e62]: Evitar el contacto con sustancias ácidas.
                  - listitem [ref=e63]: Barnizar cada 3 años para mantener sus propiedades.
    - generic [ref=e64]:
      - heading "Ventas antiguas" [level=2] [ref=e66]
      - generic [ref=e67]:
        - generic [ref=e68]:
          - generic [ref=e69]:
            - heading "Silla de caña" [level=3] [ref=e70]
            - paragraph [ref=e71]: Hoy les presentamos la silla de caña. Poseedora de herrajes metálicos resistentes y de pequeño tamaño, la convierte en una silla sin uniones robustas y molestas. Con patas de un alto promedio y base amortiguadore es apta para todo piso. Dado su material de construcción, caña proveniente de Brasil, resulta liviana y de gran duración frente a agentes climáticos extremos, desde temperaturas hasta presencia de agua y sustancias agresivas.
          - img "seccion3" [ref=e73]
          - table [ref=e76]:
            - rowgroup [ref=e77]:
              - row [ref=e78]:
                - columnheader "Producto" [ref=e79]
                - columnheader "Especificaciones" [ref=e80]
                - columnheader "Costo" [ref=e81]
                - columnheader "Beneficios" [ref=e82]
                - columnheader "Recomendaciones" [ref=e83]
              - row [ref=e84]:
                - cell "Silla de caña" [ref=e85]
                - cell [ref=e86]:
                  - list [ref=e87]:
                    - listitem [ref=e88]: Altura de 50cm
                    - listitem [ref=e89]: Ancho y largo de 35cm
                    - listitem [ref=e90]: Peso de 4.25kg
                    - listitem [ref=e91]: Uso exterior e interior
                - cell "$2350" [ref=e92]
                - cell [ref=e93]:
                  - list [ref=e94]:
                    - listitem [ref=e95]: Impermeable
                    - listitem [ref=e96]: Liviana
                    - listitem [ref=e97]: Duradera
                    - listitem [ref=e98]: Permite su uso con otros muebles de la mismaángulo.
                - cell [ref=e99]:
                  - list [ref=e100]:
                    - listitem [ref=e101]: Evitar superar los 300kg de peso apoyado.
                    - listitem [ref=e102]: Barnizar cada 1 año para mantener sus propiedades.
          - link [ref=e104] [cursor=pointer]:
            - /url: "#"
            - heading "Comprar" [level=4] [ref=e105]
        - generic [ref=e106]:
          - generic [ref=e107]:
            - heading "Tabla para picar" [level=3] [ref=e108]
            - paragraph [ref=e109]: La tabla para pcar ha sidor sorpresivamente uno de los productos más requeridos por el público. Su diseño y material la hacen especifica paa cumplir su función. Su forma se adapta a los tamaños medios de alimentos, aptos para ser picados y reservados en la misma tabla hasta ser utilizados. Debido a la madera de Algarrobo que la constituye, es resitente a la abrasión dada por elementos filosos como cuchillos. De poco peso, facil de limpiar y agradable a la vista, esta tabla supera ampliamente a las demás tablas del mercado.
          - img "tablaparapicar" [ref=e111]
          - table [ref=e114]:
            - rowgroup [ref=e115]:
              - row [ref=e116]:
                - columnheader "Producto" [ref=e117]
                - columnheader "Especificaciones" [ref=e118]
                - columnheader "Costo" [ref=e119]
                - columnheader "Beneficios" [ref=e120]
                - columnheader "Recomendaciones" [ref=e121]
              - row [ref=e122]:
                - cell "Tabla para picar" [ref=e123]
                - cell [ref=e124]:
                  - list [ref=e125]:
                    - listitem [ref=e126]: Espesor de 2.5cm
                    - listitem [ref=e127]: Largo de 30cm
                    - listitem [ref=e128]: Ancho de 25cm
                    - listitem [ref=e129]: Peso de 2.6kg
                - cell "$1100" [ref=e130]
                - cell [ref=e131]:
                  - list [ref=e132]:
                    - listitem [ref=e133]: Impermeable
                    - listitem [ref=e134]: Liviana
                    - listitem [ref=e135]: Resistente
                - cell [ref=e136]:
                  - list [ref=e137]:
                    - listitem [ref=e138]: Evitar el contacto con sustancias ácidas.
                    - listitem [ref=e139]: No colocar en microondas.
          - link [ref=e141] [cursor=pointer]:
            - /url: "#"
            - heading "Comprar" [level=4] [ref=e142]
        - generic [ref=e143]:
          - generic [ref=e144]:
            - heading "Silla de troncos" [level=3] [ref=e145]
            - paragraph [ref=e146]: La silla de troncos posee un diseño particular en el cual combina troncos de Abedul como elementos de soporte principal y tablas de Osmo que forman la base del asiento. Su diseño posee un respaldo en ángulo mayor a 90 grados, permitiendo un descanso de la espalda adecuado. El asiento logra una cómoda postura y su altura la hace capaz de ser combinada con la mayoría de las mesas que existen en nuestro catálogo.
          - img "silladetroncos" [ref=e148]
          - table [ref=e151]:
            - rowgroup [ref=e152]:
              - row [ref=e153]:
                - columnheader "Producto" [ref=e154]
                - columnheader "Especificaciones" [ref=e155]
                - columnheader "Costo" [ref=e156]
                - columnheader "Beneficios" [ref=e157]
                - columnheader "Recomendaciones" [ref=e158]
              - row [ref=e159]:
                - cell "Silla de troncos" [ref=e160]
                - cell [ref=e161]:
                  - list [ref=e162]:
                    - listitem [ref=e163]: Altura de 45cm
                    - listitem [ref=e164]: Lados de 40cm
                    - listitem [ref=e165]: Peso de 5,5kg
                    - listitem [ref=e166]: Uso interior
                - cell "$1900" [ref=e167]
                - cell [ref=e168]:
                  - list [ref=e169]:
                    - listitem [ref=e170]: Cómoda
                    - listitem [ref=e171]: Liviana
                    - listitem [ref=e172]: Resistente
                    - listitem [ref=e173]: Permite su uso con otros muebles de la mismaángulo.
                - cell [ref=e174]:
                  - list [ref=e175]:
                    - listitem [ref=e176]: Evitar el contacto con sustancias ácidas.
                    - listitem [ref=e177]: Barnizar si se requiereaumentar su durabilidad.
          - link [ref=e179] [cursor=pointer]:
            - /url: "#"
            - heading "Comprar" [level=4] [ref=e180]
        - generic [ref=e181]:
          - generic [ref=e182]:
            - heading "Mesada de Fresno" [level=3] [ref=e183]
            - paragraph [ref=e184]: Hoy les presentamos el escritorio rebatible, de variedad de cajones, soportes bifurcados aptos para todo piso. Anclado al muro de cualquier zona de la casa, es capaz de expandirse en un hermoso apoyo para estudiar, comer, leer y mucho más, y en simultaneo, puede rebatirse, de manera que reduce el espacio de uso. Esta disposicion permite un aprovechamiento de los distintos lugares del local de la manera mas efectiva.Esta compuesto de madera de roble, con cortes especialmente diseñados para mantener la resistencia del escritorio, sin afectar su durabilidad ni ser demasiado pesado.
          - img "mesadadefresno" [ref=e186]
          - table [ref=e189]:
            - rowgroup [ref=e190]:
              - row [ref=e191]:
                - columnheader "Producto" [ref=e192]
                - columnheader "Especificaciones" [ref=e193]
                - columnheader "Costo" [ref=e194]
                - columnheader "Beneficios" [ref=e195]
                - columnheader "Recomendaciones" [ref=e196]
              - row [ref=e197]:
                - cell "Mesada de Fresno" [ref=e198]
                - cell [ref=e199]:
                  - list [ref=e200]:
                    - listitem [ref=e201]: Altura de 60cm
                    - listitem [ref=e202]: Ancho de 110cm
                    - listitem [ref=e203]: Largo de 200cm
                    - listitem [ref=e204]: Peso de 12kg
                - cell "$3500" [ref=e205]
                - cell [ref=e206]:
                  - list [ref=e207]:
                    - listitem [ref=e208]: Extensible
                    - listitem [ref=e209]: Branizada
                    - listitem [ref=e210]: Resistente
                    - listitem [ref=e211]: Permite su uso con otros muebles de la mismaángulo.
                - cell [ref=e212]:
                  - list [ref=e213]:
                    - listitem [ref=e214]: Evitar el contacto con sustancias ácidas.
                    - listitem [ref=e215]: Barnizar cada 3 años para mantener sus propiedades.
          - link [ref=e217] [cursor=pointer]:
            - /url: "#"
            - heading "Comprar" [level=4] [ref=e218]
  - contentinfo [ref=e219]:
    - generic [ref=e221]:
      - heading "Proveedores" [level=2] [ref=e222]
      - generic [ref=e223]:
        - img "provedor5" [ref=e224]
        - img "provedor1" [ref=e225]
        - img "provedor2" [ref=e226]
        - img "provedor3" [ref=e227]
        - img "provedor4" [ref=e228]
    - generic [ref=e230]:
      - generic [ref=e231]:
        - heading "Contacto" [level=2] [ref=e232]
        - list [ref=e234]:
          - listitem [ref=e235]: ligninamadera@gmail.com
          - listitem [ref=e236]: 02965 743 561
          - listitem [ref=e237]: 8370 San Martín de los Andes, Neuquén, Argentina
      - generic [ref=e238]:
        - heading "Ubicación en mapa" [level=2] [ref=e239]
        - iframe [ref=e240]
      - generic [ref=e241]:
        - heading "Atención al cliente" [level=2] [ref=e242]
        - list [ref=e244]:
          - listitem [ref=e245]:
            - link "Envíos" [ref=e246] [cursor=pointer]:
              - /url: "#"
          - listitem [ref=e247]:
            - link "Plazos" [ref=e248] [cursor=pointer]:
              - /url: "#"
          - listitem [ref=e249]:
            - link "Legales" [ref=e250] [cursor=pointer]:
              - /url: "#"
          - listitem [ref=e251]:
            - link "Pago" [ref=e252] [cursor=pointer]:
              - /url: "#"
      - generic [ref=e253]:
        - heading "Newsletter" [level=2] [ref=e254]
        - generic [ref=e255]:
          - textbox "Email" [ref=e257]
          - button "Submit" [ref=e259] [cursor=pointer]
    - generic [ref=e260]:
      - generic [ref=e261]:
        - list:
          - listitem:
            - link:
              - /url: https://www.facebook.com
          - listitem:
            - link:
              - /url: https://www.whatsapp.com
          - listitem:
            - link:
              - /url: https://www.instagram.com/
      - img "logo5" [ref=e263]
      - heading "Copyright 2021 - 2021 | Lignina Tienda Online | Todos los derechos reservados" [level=4] [ref=e265]
      - heading "|Hecho por Aquí y Aurora|" [level=4] [ref=e267]
  - generic "Scroll to Top" [ref=e268] [cursor=pointer]
```

# Test source

```ts
  38  |     knownBug('MLIG-105');
  39  |     const filas = await page.locator('#mains2 button[data-bs-target$="Modal"]').evaluateAll((botones) =>
  40  |       botones.map((b) => {
  41  |         const modal = document.querySelector(b.dataset.bsTarget);
  42  |         return {
  43  |           modal: b.dataset.bsTarget,
  44  |           boton: b.textContent.trim(),
  45  |           titulo: modal.querySelector('.modal-title').textContent.trim(),
  46  |           alt: b.closest('[id^="d"]').querySelector('img').getAttribute('alt') || '',
  47  |         };
  48  |       }));
  49  |     const mal = filas.filter((f) => !mismoProducto(f.boton, f.titulo));
  50  |     expect(mal.map((f) => `${f.modal}: botón "${f.boton}" ≠ título "${f.titulo}"`)).toEqual([]);
  51  |   });
  52  | 
  53  |   // CP-04.4 · CA4 (MLIG-43)
  54  |   test('CP-04.4 · todos los precios usan el formato "$ 15.000"', async ({ page }) => {
  55  |     knownBug('MLIG-106');
  56  |     const precios = await page.locator('#mains2 .modal-body strong').allTextContents();
  57  |     expect(precios.length).toBeGreaterThan(0);
  58  |     const mal = precios.map((p) => p.trim()).filter((p) => !PRECIO_OK.test(p));
  59  |     expect(mal, 'precios con formato distinto').toEqual([]);
  60  |   });
  61  | 
  62  |   test('CP-04.4 · el precio de Venta de la semana usa el mismo formato', async ({ page }) => {
  63  |     knownBug('MLIG-106');
  64  |     await page.goto(PAGINAS.venta);
  65  |     const precios = await page.locator('td.columna3').allTextContents();
  66  |     const mal = precios.map((p) => p.trim()).filter((p) => !PRECIO_OK.test(p));
  67  |     expect(mal, 'precios con formato distinto').toEqual([]);
  68  |   });
  69  | });
  70  | 
  71  | test.describe('US-05 · Comprar un producto desde su detalle (MLIG-5)', () => {
  72  |   const confirmacion = (page) => page.getByText(/agregad[oa]|a[ñn]adid[oa]|al carrito/i);
  73  | 
  74  |   // CP-05.1 · CA1 (MLIG-44)
  75  |   test('CP-05.1 · "Comprar" en Categorías agrega la Mesada y muestra confirmación', async ({ page }) => {
  76  |     knownBug('MLIG-107');
  77  |     await page.goto(PAGINAS.categorias);
  78  |     const modal = await abrirDetalle(page, 'd12');
  79  |     await modal.getByRole('button', { name: 'Comprar' }).click();
  80  |     await expect(confirmacion(page)).toBeVisible();
  81  |   });
  82  | 
  83  |   // CP-05.2 · CA2 (MLIG-45)
  84  |   test('CP-05.2 · "Comprar" en Ventas antiguas agrega la Silla de caña y muestra confirmación', async ({ page }) => {
  85  |     knownBug('MLIG-108');
  86  |     await page.goto(PAGINAS.venta);
  87  |     await page.locator('#ventaA #linkcomprar a').click();
  88  |     await expect(confirmacion(page)).toBeVisible();
  89  |   });
  90  | 
  91  |   // CP-05.3 · CA3 (MLIG-46)
  92  |   test('CP-05.3 · cerrar el detalle (Cerrar y X) no agrega nada al carrito', async ({ page }) => {
  93  |     await page.goto(PAGINAS.categorias);
  94  |     for (const via of ['Cerrar', 'X']) {
  95  |       const modal = await abrirDetalle(page, 'd21'); // Lavabo
  96  |       if (via === 'Cerrar') await modal.getByRole('button', { name: 'Cerrar' }).click();
  97  |       else await modal.locator('.btn-close').click();
  98  |       await expect(modal).toBeHidden();
  99  |     }
  100 |     await page.getByRole('link', { name: /carro/i }).click();
  101 |     await expect(page).toHaveURL(/carro_de_compras\.html$/);
  102 |     await expect(page.getByText('Lavabo')).toHaveCount(0);
  103 |   });
  104 | });
  105 | 
  106 | test.describe('US-06 · Ver la venta de la semana (MLIG-6)', () => {
  107 |   test.beforeEach(async ({ page }) => {
  108 |     await page.goto(PAGINAS.venta);
  109 |   });
  110 | 
  111 |   // CP-06.1 · CA1 (MLIG-47)
  112 |   test('CP-06.1 · el producto destacado muestra nombre, imagen, tabla y precio', async ({ page }) => {
  113 |     await expect(page.getByRole('heading', { name: 'Banco de madera' }).first()).toBeVisible();
  114 |     await expect(page.locator('#imgs3 img')).toBeVisible();
  115 |     const tabla = page.locator('table').first();
  116 |     await expect(tabla.getByRole('columnheader')).toHaveText(['Producto', 'Especificaciones', 'Costo', 'Beneficios', 'Recomendaciones']);
  117 |     await expect(tabla.locator('td.columna3')).toContainText(/\$\s?1\.?550/);
  118 |   });
  119 | 
  120 |   // CP-06.2 · CA2 (MLIG-48)
  121 |   const antiguas = [
  122 |     ['ventaA', 'Silla de caña', /2\.?350/],
  123 |     ['ventaB', 'Tabla para picar', /1\.?100/],
  124 |     ['ventaC', 'Silla de troncos', /1\.?900/],
  125 |     ['ventaD', 'Mesada de Fresno', /3\.?500/], // el plan de pruebas lista 3; el sitio tiene 4
  126 |   ];
  127 |   for (const [id, nombre, precio] of antiguas) {
  128 |     test(`CP-06.2 · "${nombre}" muestra nombre, imagen y precio`, async ({ page }) => {
  129 |       const bloque = page.locator(`#${id}`);
  130 |       await expect(bloque.getByRole('heading', { name: nombre })).toBeVisible();
  131 |       await expect(bloque.locator('img').first()).toBeVisible();
  132 |       await expect(bloque.locator('td.columna3')).toContainText(precio);
  133 |     });
  134 | 
  135 |     test(`CP-06.2 · "Comprar" de "${nombre}" no apunta a "#"`, async ({ page }) => {
  136 |       knownBug('MLIG-108');
  137 |       const href = await page.locator(`#${id} #linkcomprar a`).getAttribute('href');
> 138 |       expect(href, 'el enlace Comprar debe ejecutar una compra').not.toBe('#');
      |                                                                      ^ Error: el enlace Comprar debe ejecutar una compra
  139 |     });
  140 |   }
  141 | });
  142 | 
```