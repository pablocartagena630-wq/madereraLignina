# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: us04-06-catalogo.spec.js >> US-05 · Comprar un producto desde su detalle (MLIG-5) >> CP-05.2 · "Comprar" en Ventas antiguas agrega la Silla de caña y muestra confirmación
- Location: tests/us04-06-catalogo.spec.js:84:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/agregad[oa]|a[ñn]adid[oa]|al carrito/i)
Expected: visible
Timeout: 2000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText(/agregad[oa]|a[ñn]adid[oa]|al carrito/i) with timeout 2000ms
  - waiting for getByText(/agregad[oa]|a[ñn]adid[oa]|al carrito/i)

```

```yaml
- banner:
  - img "logo"
  - link "Registrarse":
    - /url: ../pages-01/registro.html
  - link "Ingresar":
    - /url: ../pages-01/ingreso.html
  - link "carrodecompras":
    - /url: ../pages-01/carro_de_compras.html
    - img "carrodecompras"
  - navigation:
    - list:
      - listitem:
        - link "Nosotros":
          - /url: ../pages-01/seccion1.html
      - listitem:
        - link "Categorías":
          - /url: ../pages-01/seccion2.html
      - listitem:
        - link "Venta de la semana":
          - /url: ../pages-01/seccion3.html
      - listitem:
        - link "Consejos":
          - /url: ../pages-01/seccion4.html
      - listitem:
        - link "Comentarios":
          - /url: ../pages-01/seccion5.html
      - listitem:
        - link "Volver al inicio":
          - /url: ../index.html
- main:
  - heading "Venta de la semana" [level=2]
  - heading "Banco de madera" [level=3]
  - paragraph: Les presentamos el banco de madera. Posee herrajes metálicos resistentes y de pequeño tamaño. Con patas de un alto promedio y base amortiguadore es apta para todo piso y permite un apoyo cómodo y resistente. Esta compuesto por madera de Lapacho, lo cual resulta en un elemento de peso mediano y de gran duración frente a agentes climaticos extremos. Es resistente a golpes y abrasión por distintos objetos. Se encuentra revestido de una fina capa de barniz para potenciar sus colores naturales junto con una protección frente a la humedad.
  - img "seccion3"
  - table:
    - rowgroup:
      - row "Producto Especificaciones Costo Beneficios Recomendaciones":
        - columnheader "Producto"
        - columnheader "Especificaciones"
        - columnheader "Costo"
        - columnheader "Beneficios"
        - columnheader "Recomendaciones"
      - row "Banco de madera Altura de 50cm Largo de 150cm Peso de 10,5kg Uso interior $1550 Impermeable Liviano Resistente Permite su uso con otros muebles de la mismaángulo. Evitar el contacto con sustancias ácidas. Barnizar cada 3 años para mantener sus propiedades.":
        - cell "Banco de madera"
        - cell "Altura de 50cm Largo de 150cm Peso de 10,5kg Uso interior":
          - list:
            - listitem: Altura de 50cm
            - listitem: Largo de 150cm
            - listitem: Peso de 10,5kg
            - listitem: Uso interior
        - cell "$1550"
        - cell "Impermeable Liviano Resistente Permite su uso con otros muebles de la mismaángulo.":
          - list:
            - listitem: Impermeable
            - listitem: Liviano
            - listitem: Resistente
            - listitem: Permite su uso con otros muebles de la mismaángulo.
        - cell "Evitar el contacto con sustancias ácidas. Barnizar cada 3 años para mantener sus propiedades.":
          - list:
            - listitem: Evitar el contacto con sustancias ácidas.
            - listitem: Barnizar cada 3 años para mantener sus propiedades.
  - heading "Ventas antiguas" [level=2]
  - heading "Silla de caña" [level=3]
  - paragraph: Hoy les presentamos la silla de caña. Poseedora de herrajes metálicos resistentes y de pequeño tamaño, la convierte en una silla sin uniones robustas y molestas. Con patas de un alto promedio y base amortiguadore es apta para todo piso. Dado su material de construcción, caña proveniente de Brasil, resulta liviana y de gran duración frente a agentes climáticos extremos, desde temperaturas hasta presencia de agua y sustancias agresivas.
  - img "seccion3"
  - table:
    - rowgroup:
      - row "Producto Especificaciones Costo Beneficios Recomendaciones":
        - columnheader "Producto"
        - columnheader "Especificaciones"
        - columnheader "Costo"
        - columnheader "Beneficios"
        - columnheader "Recomendaciones"
      - row "Silla de caña Altura de 50cm Ancho y largo de 35cm Peso de 4.25kg Uso exterior e interior $2350 Impermeable Liviana Duradera Permite su uso con otros muebles de la mismaángulo. Evitar superar los 300kg de peso apoyado. Barnizar cada 1 año para mantener sus propiedades.":
        - cell "Silla de caña"
        - cell "Altura de 50cm Ancho y largo de 35cm Peso de 4.25kg Uso exterior e interior":
          - list:
            - listitem: Altura de 50cm
            - listitem: Ancho y largo de 35cm
            - listitem: Peso de 4.25kg
            - listitem: Uso exterior e interior
        - cell "$2350"
        - cell "Impermeable Liviana Duradera Permite su uso con otros muebles de la mismaángulo.":
          - list:
            - listitem: Impermeable
            - listitem: Liviana
            - listitem: Duradera
            - listitem: Permite su uso con otros muebles de la mismaángulo.
        - cell "Evitar superar los 300kg de peso apoyado. Barnizar cada 1 año para mantener sus propiedades.":
          - list:
            - listitem: Evitar superar los 300kg de peso apoyado.
            - listitem: Barnizar cada 1 año para mantener sus propiedades.
  - link "Comprar":
    - /url: "#"
    - heading "Comprar" [level=4]
  - heading "Tabla para picar" [level=3]
  - paragraph: La tabla para pcar ha sidor sorpresivamente uno de los productos más requeridos por el público. Su diseño y material la hacen especifica paa cumplir su función. Su forma se adapta a los tamaños medios de alimentos, aptos para ser picados y reservados en la misma tabla hasta ser utilizados. Debido a la madera de Algarrobo que la constituye, es resitente a la abrasión dada por elementos filosos como cuchillos. De poco peso, facil de limpiar y agradable a la vista, esta tabla supera ampliamente a las demás tablas del mercado.
  - img "tablaparapicar"
  - table:
    - rowgroup:
      - row "Producto Especificaciones Costo Beneficios Recomendaciones":
        - columnheader "Producto"
        - columnheader "Especificaciones"
        - columnheader "Costo"
        - columnheader "Beneficios"
        - columnheader "Recomendaciones"
      - row "Tabla para picar Espesor de 2.5cm Largo de 30cm Ancho de 25cm Peso de 2.6kg $1100 Impermeable Liviana Resistente Evitar el contacto con sustancias ácidas. No colocar en microondas.":
        - cell "Tabla para picar"
        - cell "Espesor de 2.5cm Largo de 30cm Ancho de 25cm Peso de 2.6kg":
          - list:
            - listitem: Espesor de 2.5cm
            - listitem: Largo de 30cm
            - listitem: Ancho de 25cm
            - listitem: Peso de 2.6kg
        - cell "$1100"
        - cell "Impermeable Liviana Resistente":
          - list:
            - listitem: Impermeable
            - listitem: Liviana
            - listitem: Resistente
        - cell "Evitar el contacto con sustancias ácidas. No colocar en microondas.":
          - list:
            - listitem: Evitar el contacto con sustancias ácidas.
            - listitem: No colocar en microondas.
  - link "Comprar":
    - /url: "#"
    - heading "Comprar" [level=4]
  - heading "Silla de troncos" [level=3]
  - paragraph: La silla de troncos posee un diseño particular en el cual combina troncos de Abedul como elementos de soporte principal y tablas de Osmo que forman la base del asiento. Su diseño posee un respaldo en ángulo mayor a 90 grados, permitiendo un descanso de la espalda adecuado. El asiento logra una cómoda postura y su altura la hace capaz de ser combinada con la mayoría de las mesas que existen en nuestro catálogo.
  - img "silladetroncos"
  - table:
    - rowgroup:
      - row "Producto Especificaciones Costo Beneficios Recomendaciones":
        - columnheader "Producto"
        - columnheader "Especificaciones"
        - columnheader "Costo"
        - columnheader "Beneficios"
        - columnheader "Recomendaciones"
      - row "Silla de troncos Altura de 45cm Lados de 40cm Peso de 5,5kg Uso interior $1900 Cómoda Liviana Resistente Permite su uso con otros muebles de la mismaángulo. Evitar el contacto con sustancias ácidas. Barnizar si se requiereaumentar su durabilidad.":
        - cell "Silla de troncos"
        - cell "Altura de 45cm Lados de 40cm Peso de 5,5kg Uso interior":
          - list:
            - listitem: Altura de 45cm
            - listitem: Lados de 40cm
            - listitem: Peso de 5,5kg
            - listitem: Uso interior
        - cell "$1900"
        - cell "Cómoda Liviana Resistente Permite su uso con otros muebles de la mismaángulo.":
          - list:
            - listitem: Cómoda
            - listitem: Liviana
            - listitem: Resistente
            - listitem: Permite su uso con otros muebles de la mismaángulo.
        - cell "Evitar el contacto con sustancias ácidas. Barnizar si se requiereaumentar su durabilidad.":
          - list:
            - listitem: Evitar el contacto con sustancias ácidas.
            - listitem: Barnizar si se requiereaumentar su durabilidad.
  - link "Comprar":
    - /url: "#"
    - heading "Comprar" [level=4]
  - heading "Mesada de Fresno" [level=3]
  - paragraph: Hoy les presentamos el escritorio rebatible, de variedad de cajones, soportes bifurcados aptos para todo piso. Anclado al muro de cualquier zona de la casa, es capaz de expandirse en un hermoso apoyo para estudiar, comer, leer y mucho más, y en simultaneo, puede rebatirse, de manera que reduce el espacio de uso. Esta disposicion permite un aprovechamiento de los distintos lugares del local de la manera mas efectiva.Esta compuesto de madera de roble, con cortes especialmente diseñados para mantener la resistencia del escritorio, sin afectar su durabilidad ni ser demasiado pesado.
  - img "mesadadefresno"
  - table:
    - rowgroup:
      - row "Producto Especificaciones Costo Beneficios Recomendaciones":
        - columnheader "Producto"
        - columnheader "Especificaciones"
        - columnheader "Costo"
        - columnheader "Beneficios"
        - columnheader "Recomendaciones"
      - row "Mesada de Fresno Altura de 60cm Ancho de 110cm Largo de 200cm Peso de 12kg $3500 Extensible Branizada Resistente Permite su uso con otros muebles de la mismaángulo. Evitar el contacto con sustancias ácidas. Barnizar cada 3 años para mantener sus propiedades.":
        - cell "Mesada de Fresno"
        - cell "Altura de 60cm Ancho de 110cm Largo de 200cm Peso de 12kg":
          - list:
            - listitem: Altura de 60cm
            - listitem: Ancho de 110cm
            - listitem: Largo de 200cm
            - listitem: Peso de 12kg
        - cell "$3500"
        - cell "Extensible Branizada Resistente Permite su uso con otros muebles de la mismaángulo.":
          - list:
            - listitem: Extensible
            - listitem: Branizada
            - listitem: Resistente
            - listitem: Permite su uso con otros muebles de la mismaángulo.
        - cell "Evitar el contacto con sustancias ácidas. Barnizar cada 3 años para mantener sus propiedades.":
          - list:
            - listitem: Evitar el contacto con sustancias ácidas.
            - listitem: Barnizar cada 3 años para mantener sus propiedades.
  - link "Comprar":
    - /url: "#"
    - heading "Comprar" [level=4]
- contentinfo:
  - heading "Proveedores" [level=2]
  - img "provedor5"
  - img "provedor1"
  - img "provedor2"
  - img "provedor3"
  - img "provedor4"
  - heading "Contacto" [level=2]
  - list:
    - listitem: ligninamadera@gmail.com
    - listitem: 02965 743 561
    - listitem: 8370 San Martín de los Andes, Neuquén, Argentina
  - heading "Ubicación en mapa" [level=2]
  - iframe
  - heading "Atención al cliente" [level=2]
  - list:
    - listitem:
      - link "Envíos":
        - /url: "#"
    - listitem:
      - link "Plazos":
        - /url: "#"
    - listitem:
      - link "Legales":
        - /url: "#"
    - listitem:
      - link "Pago":
        - /url: "#"
  - heading "Newsletter" [level=2]
  - textbox "Email"
  - button "Submit"
  - list:
    - listitem:
      - link:
        - /url: https://www.facebook.com
    - listitem:
      - link:
        - /url: https://www.whatsapp.com
    - listitem:
      - link:
        - /url: https://www.instagram.com/
  - img "logo5"
  - heading "Copyright 2021 - 2021 | Lignina Tienda Online | Todos los derechos reservados" [level=4]
  - heading "|Hecho por Aquí y Aurora|" [level=4]
- img
```

# Test source

```ts
  1   | const { test, expect, knownBug, mismoProducto, CATEGORIAS, PAGINAS, PRECIO_OK } = require('./helpers');
  2   | 
  3   | /** Abre el detalle de un producto de seccion2 por su id de contenedor (ej. "d12"). */
  4   | const abrirDetalle = async (page, id) => {
  5   |   await page.locator(`#${id} button[data-bs-toggle="modal"]`).click();
  6   |   const modal = page.locator(`#${id}Modal`);
  7   |   await expect(modal).toBeVisible();
  8   |   return modal;
  9   | };
  10  | 
  11  | test.describe('US-04 · Ver los productos de cada categoría (MLIG-4)', () => {
  12  |   test.beforeEach(async ({ page }) => {
  13  |     await page.goto(PAGINAS.categorias);
  14  |   });
  15  | 
  16  |   // CP-04.1 · CA1 (MLIG-40)
  17  |   test('CP-04.1 · 7 categorías, 28 productos y ninguna imagen rota', async ({ page }) => {
  18  |     for (const c of CATEGORIAS) await expect(page.locator(`#${c.ancla}`)).toBeAttached();
  19  |     await expect(page.locator('#mains2 button[data-bs-target$="Modal"]')).toHaveCount(28);
  20  | 
  21  |     await page.waitForLoadState('load');
  22  |     const rotas = await page.locator('#mains2 img').evaluateAll((imgs) =>
  23  |       imgs.filter((i) => !i.complete || i.naturalWidth === 0).map((i) => i.getAttribute('src')));
  24  |     expect(rotas, `imágenes rotas: ${rotas.join(', ')}`).toEqual([]);
  25  |   });
  26  | 
  27  |   // CP-04.2 · CA2 (MLIG-41)
  28  |   test('CP-04.2 · el detalle del Escritorio muestra nombre, imagen, descripción y precio', async ({ page }) => {
  29  |     const modal = await abrirDetalle(page, 'd11');
  30  |     await expect(modal.locator('.modal-title')).toHaveText('Escritorio');
  31  |     await expect(modal.locator('img')).toBeVisible();
  32  |     await expect(modal.locator('.modal-body p').first()).not.toBeEmpty();
  33  |     await expect(modal.getByText(/Precio:/)).toContainText(/\$\s?4\.?200/);
  34  |   });
  35  | 
  36  |   // CP-04.3 · CA3 (MLIG-42)
  37  |   test('CP-04.3 · el título de cada detalle corresponde al producto de su botón e imagen', async ({ page }) => {
  38  |     knownBug('MLIG-105');
  39  |     const filas = await page.locator('#mains2 button[data-bs-target$="Modal"]').evaluateAll((botones) =>
  40  |       botones.map((b) => {
  41  |         const modal = document.querySelector(b.dataset.bsTarget);
  42  |         return {
  43  |           modal: b.dataset.bsTarget,
  44  |           boton: b.textContent.trim(),
  45  |           titulo: modal.querySelector('.modal-title').textContent.trim(),
  46  |           alt: b.closest('[id^="d"]').querySelector('img').getAttribute('alt') || '',
  47  |         };
  48  |       }));
  49  |     const mal = filas.filter((f) => !mismoProducto(f.boton, f.titulo));
  50  |     expect(mal.map((f) => `${f.modal}: botón "${f.boton}" ≠ título "${f.titulo}"`)).toEqual([]);
  51  |   });
  52  | 
  53  |   // CP-04.4 · CA4 (MLIG-43)
  54  |   test('CP-04.4 · todos los precios usan el formato "$ 15.000"', async ({ page }) => {
  55  |     knownBug('MLIG-106');
  56  |     const precios = await page.locator('#mains2 .modal-body strong').allTextContents();
  57  |     expect(precios.length).toBeGreaterThan(0);
  58  |     const mal = precios.map((p) => p.trim()).filter((p) => !PRECIO_OK.test(p));
  59  |     expect(mal, 'precios con formato distinto').toEqual([]);
  60  |   });
  61  | 
  62  |   test('CP-04.4 · el precio de Venta de la semana usa el mismo formato', async ({ page }) => {
  63  |     knownBug('MLIG-106');
  64  |     await page.goto(PAGINAS.venta);
  65  |     const precios = await page.locator('td.columna3').allTextContents();
  66  |     const mal = precios.map((p) => p.trim()).filter((p) => !PRECIO_OK.test(p));
  67  |     expect(mal, 'precios con formato distinto').toEqual([]);
  68  |   });
  69  | });
  70  | 
  71  | test.describe('US-05 · Comprar un producto desde su detalle (MLIG-5)', () => {
  72  |   const confirmacion = (page) => page.getByText(/agregad[oa]|a[ñn]adid[oa]|al carrito/i);
  73  | 
  74  |   // CP-05.1 · CA1 (MLIG-44)
  75  |   test('CP-05.1 · "Comprar" en Categorías agrega la Mesada y muestra confirmación', async ({ page }) => {
  76  |     knownBug('MLIG-107');
  77  |     await page.goto(PAGINAS.categorias);
  78  |     const modal = await abrirDetalle(page, 'd12');
  79  |     await modal.getByRole('button', { name: 'Comprar' }).click();
  80  |     await expect(confirmacion(page)).toBeVisible();
  81  |   });
  82  | 
  83  |   // CP-05.2 · CA2 (MLIG-45)
  84  |   test('CP-05.2 · "Comprar" en Ventas antiguas agrega la Silla de caña y muestra confirmación', async ({ page }) => {
  85  |     knownBug('MLIG-108');
  86  |     await page.goto(PAGINAS.venta);
  87  |     await page.locator('#ventaA #linkcomprar a').click();
> 88  |     await expect(confirmacion(page)).toBeVisible();
      |                                      ^ Error: expect(locator).toBeVisible() failed
  89  |   });
  90  | 
  91  |   // CP-05.3 · CA3 (MLIG-46)
  92  |   test('CP-05.3 · cerrar el detalle (Cerrar y X) no agrega nada al carrito', async ({ page }) => {
  93  |     await page.goto(PAGINAS.categorias);
  94  |     for (const via of ['Cerrar', 'X']) {
  95  |       const modal = await abrirDetalle(page, 'd21'); // Lavabo
  96  |       if (via === 'Cerrar') await modal.getByRole('button', { name: 'Cerrar' }).click();
  97  |       else await modal.locator('.btn-close').click();
  98  |       await expect(modal).toBeHidden();
  99  |     }
  100 |     await page.getByRole('link', { name: /carro/i }).click();
  101 |     await expect(page).toHaveURL(/carro_de_compras\.html$/);
  102 |     await expect(page.getByText('Lavabo')).toHaveCount(0);
  103 |   });
  104 | });
  105 | 
  106 | test.describe('US-06 · Ver la venta de la semana (MLIG-6)', () => {
  107 |   test.beforeEach(async ({ page }) => {
  108 |     await page.goto(PAGINAS.venta);
  109 |   });
  110 | 
  111 |   // CP-06.1 · CA1 (MLIG-47)
  112 |   test('CP-06.1 · el producto destacado muestra nombre, imagen, tabla y precio', async ({ page }) => {
  113 |     await expect(page.getByRole('heading', { name: 'Banco de madera' }).first()).toBeVisible();
  114 |     await expect(page.locator('#imgs3 img')).toBeVisible();
  115 |     const tabla = page.locator('table').first();
  116 |     await expect(tabla.getByRole('columnheader')).toHaveText(['Producto', 'Especificaciones', 'Costo', 'Beneficios', 'Recomendaciones']);
  117 |     await expect(tabla.locator('td.columna3')).toContainText(/\$\s?1\.?550/);
  118 |   });
  119 | 
  120 |   // CP-06.2 · CA2 (MLIG-48)
  121 |   const antiguas = [
  122 |     ['ventaA', 'Silla de caña', /2\.?350/],
  123 |     ['ventaB', 'Tabla para picar', /1\.?100/],
  124 |     ['ventaC', 'Silla de troncos', /1\.?900/],
  125 |     ['ventaD', 'Mesada de Fresno', /3\.?500/], // el plan de pruebas lista 3; el sitio tiene 4
  126 |   ];
  127 |   for (const [id, nombre, precio] of antiguas) {
  128 |     test(`CP-06.2 · "${nombre}" muestra nombre, imagen y precio`, async ({ page }) => {
  129 |       const bloque = page.locator(`#${id}`);
  130 |       await expect(bloque.getByRole('heading', { name: nombre })).toBeVisible();
  131 |       await expect(bloque.locator('img').first()).toBeVisible();
  132 |       await expect(bloque.locator('td.columna3')).toContainText(precio);
  133 |     });
  134 | 
  135 |     test(`CP-06.2 · "Comprar" de "${nombre}" no apunta a "#"`, async ({ page }) => {
  136 |       knownBug('MLIG-108');
  137 |       const href = await page.locator(`#${id} #linkcomprar a`).getAttribute('href');
  138 |       expect(href, 'el enlace Comprar debe ejecutar una compra').not.toBe('#');
  139 |     });
  140 |   }
  141 | });
  142 | 
```