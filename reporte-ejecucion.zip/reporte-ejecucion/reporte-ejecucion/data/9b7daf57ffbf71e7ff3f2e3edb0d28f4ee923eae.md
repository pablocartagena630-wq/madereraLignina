# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: us07-carrito.spec.js >> US-07 · Ver mi carrito de compras (MLIG-7) >> CP-07.2 · carrito vacío muestra "Tu carrito está vacío" y total $ 0
- Location: tests/us07-carrito.spec.js:25:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Tu carrito está vacío')
Expected: visible
Timeout: 2000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Tu carrito está vacío') with timeout 2000ms
  - waiting for getByText('Tu carrito está vacío')

```

```yaml
- banner:
  - img "logo"
  - link "Registrarse":
    - /url: ../pages-01/registro.html
  - link "Ingresar":
    - /url: ../pages-01/ingreso.html
  - link "carrodecompras":
    - /url: ../pages-01/carro_de_compras.html
    - img "carrodecompras"
  - link "Volver al inicio":
    - /url: ../index.html
- main:
  - heading "Carro de compras" [level=2]
- img
```

# Test source

```ts
  1  | const { test, expect, knownBug, PAGINAS } = require('./helpers');
  2  | 
  3  | const comprar = async (page, id) => {
  4  |   await page.goto(PAGINAS.categorias);
  5  |   await page.locator(`#${id} button[data-bs-toggle="modal"]`).click();
  6  |   await page.locator(`#${id}Modal`).getByRole('button', { name: 'Comprar' }).click();
  7  | };
  8  | const abrirCarro = async (page) => {
  9  |   await page.goto(PAGINAS.carro);
  10 | };
  11 | 
  12 | test.describe('US-07 · Ver mi carrito de compras (MLIG-7)', () => {
  13 |   // CP-07.1 · CA1 (MLIG-49)
  14 |   test('CP-07.1 · el carrito muestra nombre, cantidad, precio unitario y subtotal', async ({ page }) => {
  15 |     knownBug('MLIG-109');
  16 |     await comprar(page, 'd11'); // Escritorio $ 4.200
  17 |     await abrirCarro(page);
  18 |     const fila = page.getByRole('row').filter({ hasText: 'Escritorio' });
  19 |     await expect(fila).toBeVisible();
  20 |     await expect(fila).toContainText('1');
  21 |     await expect(fila).toContainText('$ 4.200');
  22 |   });
  23 | 
  24 |   // CP-07.2 · CA2 (MLIG-50)
  25 |   test('CP-07.2 · carrito vacío muestra "Tu carrito está vacío" y total $ 0', async ({ page }) => {
  26 |     knownBug('MLIG-109');
  27 |     await abrirCarro(page);
> 28 |     await expect(page.getByText('Tu carrito está vacío')).toBeVisible();
     |                                                           ^ Error: expect(locator).toBeVisible() failed
  29 |     await expect(page.getByText(/Total.*\$\s?0\b/i)).toBeVisible();
  30 |   });
  31 | 
  32 |   // CP-07.3 · CA3 (MLIG-51)
  33 |   test('CP-07.3 · el total es la suma exacta de los subtotales ($ 11.700)', async ({ page }) => {
  34 |     knownBug('MLIG-109');
  35 |     await comprar(page, 'd11'); // Escritorio  $ 4.200
  36 |     await comprar(page, 'd21'); // Lavabo      $ 6.000
  37 |     await comprar(page, 'd41'); // Silla ext.  $ 1.500
  38 |     await abrirCarro(page);
  39 |     await expect(page.getByText(/Total.*\$\s?11\.700/i)).toBeVisible();
  40 |   });
  41 | });
  42 | 
```