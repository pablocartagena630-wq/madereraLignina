# Reporte de ejecución

Ejecución completa de las pruebas automáticas, hecha el 13/11/2026 con Playwright en Chromium.

| Archivo | Qué es |
|---|---|
| `index.html` | Reporte HTML que genera Playwright con las 133 pruebas. Para verlo, descárgalo y ábrelo en el navegador. |
| `video-ejecucion-completa.mp4` | Video de las 133 pruebas, una tras otra (6 min 44 s). Arriba de cada prueba dice su caso de Jira, el resultado y el archivo de la prueba. |
| `grabacion-pantalla.mp4` | Grabación de pantalla (2 min 18 s): se corre `npm test` en Chrome y Firefox, termina con "266 passed" y se abre el reporte con `npm run report`. |

**Resultado:** 133 de 133 pruebas terminaron como se esperaba.

- Los casos que pasan salen en verde.
- Los 36 casos que fallan por un bug conocido (MLIG-103 a MLIG-128) están marcados con `knownBug`. Salen en verde porque fallan como se espera, y en el reporte cada uno muestra la clave de su bug.

Para repetir la ejecución desde `madereraLignina-main/e2e`:

```bash
npm install
npx playwright install chromium firefox
npm run test:chrome
npm run report
```
